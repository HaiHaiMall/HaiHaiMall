package neusoft.test.module.service;

import java.util.List;

import neusoft.test.module.domain.User;

public interface IUserManager {
	public static final String cacheName="userCache";
	public void userLogin(String userName, String userPwd);
	public User getUserById(String userId);
	public void addUser(String id, String userName, String userPwd);
	public void updateUser(String id, String userName, String userPwd);
	public void delUserById(String userId);
	public List<User> getAll(int pageNum,int pageSize);
	
}
