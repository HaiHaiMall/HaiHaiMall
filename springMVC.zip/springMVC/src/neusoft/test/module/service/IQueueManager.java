package neusoft.test.module.service;

public interface IQueueManager {
	public void sendMessage(String message);
	public void publish(String msg);
}
