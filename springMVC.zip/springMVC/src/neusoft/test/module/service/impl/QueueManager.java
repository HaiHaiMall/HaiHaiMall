package neusoft.test.module.service.impl;

import javax.jms.JMSException;
import javax.jms.Message;
import javax.jms.Session;

import org.apache.activemq.command.ActiveMQQueue;
import org.apache.activemq.command.ActiveMQTopic;
import org.springframework.beans.factory.annotation.Value;
import org.springframework.jms.core.JmsTemplate;
import org.springframework.jms.core.MessageCreator;
import org.springframework.stereotype.Service;

import neusoft.test.module.service.IQueueManager;
@Service("queueManager")
public class QueueManager implements  IQueueManager{
	@Value("#{jmsTemplate}")
	private JmsTemplate jmsTemplate; 
	@Value("#{queueDestination}")
	private ActiveMQQueue queueDestination; 
	@Value("#{topicJmsTemplate}")
	private JmsTemplate topicJmsTemplate;
	@Value("#{topicDestination}")
	private ActiveMQTopic topicDestination;
	@Override
	public void sendMessage(String message) {
        System.out.println("---------------生产者发了一个点对点消息：" + message);  
        jmsTemplate.send(queueDestination, new MessageCreator() {  
            public Message createMessage(Session session) throws JMSException {  
                return session.createTextMessage(message);  
            }  
        }); 
        
	}
	/** 
     * 向指定的topic发布消息 
     * @param topic 
     * @param msg 
     */  
    public void publish(String msg) {
    	System.out.println("---------------生产者发了一个topic消息：" + msg);  
        topicJmsTemplate.send(topicDestination, new MessageCreator() {  
            public Message createMessage(Session session) throws JMSException {  
                System.out.println("topic name 是" + topicDestination.toString()  
                        + "，发布消息内容为:\t" + msg);  
                return session.createTextMessage(msg);  
            }  
        });  
    }  
    /*	
	@JmsListener(destination = "myDestination")
    public void processOrder(Order order, @Header("order_type") String orderType) {
        ...
    }*/
}
