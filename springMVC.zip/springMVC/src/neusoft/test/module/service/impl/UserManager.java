package neusoft.test.module.service.impl;

import java.util.List;

import org.springframework.beans.factory.annotation.Autowired;
import org.springframework.cache.annotation.CacheConfig;
import org.springframework.cache.annotation.CacheEvict;
import org.springframework.cache.annotation.Cacheable;
import org.springframework.stereotype.Service;
import org.springframework.transaction.annotation.Transactional;

import com.github.pagehelper.PageHelper;

import neusoft.test.module.domain.User;
import neusoft.test.module.mapper.IUserMapper;
import neusoft.test.module.service.IUserManager;  
@Service("userManager")
@Transactional
@CacheConfig(cacheNames={IUserManager.cacheName})
public class UserManager implements IUserManager {
	@Autowired
	private IUserMapper userMapper;
	
	
	
	@Override
	public void userLogin(String userName, String userPwd) {
		System.out.println(userName+":login");
	}
	@Cacheable(key="#root.methodName+#root.args[0]") 
    public User getUserById(String userId){
    	System.out.println("search"+userId);
    	User user=userMapper.getUser(userId);
    	return user;
    }
	@Override
	@CacheEvict(allEntries=true)
	public void addUser(String id, String userName, String userPwd) {
		userMapper.add(id,userName,userPwd);
	}
	@Override
	@CacheEvict(allEntries=true)
	public void updateUser(String id, String userName, String userPwd) {
		System.out.println("update"+id);
    	userMapper.updateUser(id,userName,userPwd);
		
	}
	@Override
	@CacheEvict(allEntries=true)
	public void delUserById(String userId) {
		System.out.println("update"+userId);
    	userMapper.delUserById(userId);
	}
	@Override
	@Cacheable(key="#root.methodName+#root.args[0]+#root.args[1]") 
	public List<User> getAll(int pageNum,int pageSize) {
		PageHelper.startPage(pageNum, pageSize);
		List<User> userList=userMapper.getAll();
		return userList;
	}
}
