package neusoft.test.module.domain;

import java.io.Serializable;

@SuppressWarnings("serial")
public class User implements Serializable{
	private String id;//�û�id
	private String userName;//�û���
	private String userPwd;//�û�����
	
	public String getId() {
		return id;
	}
	public void setId(String id) {
		this.id = id;
	}
	public String getUserName() {
		return userName;
	}
	public void setUserName(String userName) {
		this.userName = userName;
	}
	public String getUserPwd() {
		return userPwd;
	}
	public void setUserPwd(String userPwd) {
		this.userPwd = userPwd;
	}
	
	
}
