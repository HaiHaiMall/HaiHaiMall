package neusoft.test.config;

import java.util.Properties;

import javax.sql.DataSource;

import org.apache.activemq.ActiveMQConnectionFactory;
import org.apache.activemq.command.ActiveMQQueue;
import org.apache.activemq.command.ActiveMQTopic;
import org.apache.ibatis.plugin.Interceptor;
import org.apache.ibatis.session.SqlSessionFactory;
import org.mybatis.spring.SqlSessionFactoryBean;
import org.mybatis.spring.mapper.MapperScannerConfigurer;
import org.springframework.beans.factory.annotation.Value;
import org.springframework.beans.factory.config.PropertiesFactoryBean;
import org.springframework.beans.factory.config.PropertyPlaceholderConfigurer;
import org.springframework.cache.annotation.EnableCaching;
import org.springframework.context.annotation.Bean;
import org.springframework.context.annotation.ComponentScan;
import org.springframework.context.annotation.Configuration;
import org.springframework.core.io.Resource;
import org.springframework.data.redis.cache.RedisCacheManager;
import org.springframework.data.redis.connection.jedis.JedisConnectionFactory;
import org.springframework.data.redis.core.RedisTemplate;
import org.springframework.data.redis.serializer.JdkSerializationRedisSerializer;
import org.springframework.data.redis.serializer.StringRedisSerializer;
import org.springframework.jdbc.datasource.DataSourceTransactionManager;
import org.springframework.jms.connection.SingleConnectionFactory;
import org.springframework.jms.core.JmsTemplate;
import org.springframework.jms.listener.DefaultMessageListenerContainer;
import org.springframework.transaction.PlatformTransactionManager;
import org.springframework.transaction.annotation.EnableTransactionManagement;

import com.github.pagehelper.PageInterceptor;
import com.zaxxer.hikari.HikariDataSource;

import neusoft.test.listener.ConsumerMessageListener;
import neusoft.test.listener.TopicMessageListener;
import redis.clients.jedis.JedisPoolConfig;

@Configuration
@EnableTransactionManagement()
//启动缓存
@EnableCaching()
//@EnableJms()
@ComponentScan(basePackages = { "neusoft.test.module.service" })
public class ModuleConfig {
	// 引入配置文件
	@Bean
	public PropertyPlaceholderConfigurer propertyPlaceholderConfigurer(
			@Value("classpath:config.properties") Resource  locationDB,
			@Value("classpath:redis.properties") Resource  locationsRedis,
			@Value("classpath:mq.properties") Resource  locationsMq) {
		PropertyPlaceholderConfigurer propertyPlaceholderConfigurer = new PropertyPlaceholderConfigurer();
		propertyPlaceholderConfigurer.setLocations(locationDB,locationsRedis,locationsMq);
		return propertyPlaceholderConfigurer;
	}


	@Bean
	public DataSource dataSource(@Value("${datasource.userName}") String userName,
			@Value("${datasource.password}") String password,
			@Value("${datasource.driverClassName}") String driverClassName,
			@Value("${datasource.jdbcUrl}") String jdbcUrl) {
		 HikariDataSource dataSource=new HikariDataSource();
		//BasicDataSource dataSource = new BasicDataSource();
		dataSource.setUsername(userName);
		dataSource.setPassword(password);
		dataSource.setDriverClassName(driverClassName);
		dataSource.setJdbcUrl(jdbcUrl);
		return dataSource;
	}
	
	// 接口所在包名，Spring会自动查找其下的类
	@Bean
	public MapperScannerConfigurer mapperScannerConfigurer() {
		MapperScannerConfigurer mapperScannerConfigurer = new MapperScannerConfigurer();
		mapperScannerConfigurer.setBasePackage("neusoft.test.module.mapper");
		return mapperScannerConfigurer;
	}

	// (事务管理)transaction manager, use JtaTransactionManager for global tx
	@Bean
	public PlatformTransactionManager transactionManager(DataSource dataSource) {
		DataSourceTransactionManager transactionManager = new DataSourceTransactionManager();
		transactionManager.setDataSource(dataSource);
		return transactionManager;
	}
	//pagehelper的资源参数文件
	@Bean
	public PropertiesFactoryBean maperHelper(@Value("classpath:helpconfig.properties")Resource location){
		PropertiesFactoryBean maperHelper=new PropertiesFactoryBean();
		maperHelper.setLocation(location);
		return maperHelper;
	}
	// spring和MyBatis完美整合，不需要mybatis的配置映射文件
	// 集成pagehelper
	@Bean
	public SqlSessionFactory sqlSessionFactory(DataSource dataSource,@Value("#{maperHelper}") Properties properties) throws Exception {
		//拦截器的方式使用pagehelper
		Interceptor interceptor=new PageInterceptor();
		interceptor.setProperties(properties);
		SqlSessionFactoryBean sqlSessionFactory = new SqlSessionFactoryBean();
		sqlSessionFactory.setDataSource(dataSource);
		sqlSessionFactory.setPlugins(new Interceptor[]{interceptor});
		return sqlSessionFactory.getObject();
	}
	//redis配置参考http://www.cnblogs.com/s648667069/p/6473412.html
	//jedis连接池 配置
	@Bean
	public JedisPoolConfig poolConfig(@Value("${redis.maxIdle}") int maxIdle,
			@Value("${redis.maxWait}") int maxWaitMillis,
			@Value("${redis.testOnBorrow}") Boolean testOnBorrow) {
		JedisPoolConfig jedisPoolConfig = new JedisPoolConfig();
		jedisPoolConfig.setMaxIdle(maxIdle);
		jedisPoolConfig.setMaxWaitMillis(maxWaitMillis);
		jedisPoolConfig.setTestOnBorrow(testOnBorrow);
		return jedisPoolConfig;
	}

	// redis服务器中心
	@Bean
	public JedisConnectionFactory connectionFactory(@Value("#{poolConfig}") JedisPoolConfig poolConfig ,@Value("${redis.host}") String hostName,
			@Value("${redis.port}") int port, @Value("${redis.maxWait}") int timeout) {
		JedisConnectionFactory jedisConnectionFactory = new JedisConnectionFactory();
		jedisConnectionFactory.setPoolConfig(poolConfig);
		jedisConnectionFactory.setHostName(hostName);
		jedisConnectionFactory.setPort(port);
		jedisConnectionFactory.setTimeout(timeout);
		return jedisConnectionFactory;
	}
	// redis template
	@Bean
	public RedisTemplate redisTemplate(@Value("#{connectionFactory}") JedisConnectionFactory connectionFactory) {
		RedisTemplate redisTemplate = new RedisTemplate();
		redisTemplate.setConnectionFactory(connectionFactory);
		StringRedisSerializer keySerializer=new StringRedisSerializer();
		redisTemplate.setKeySerializer(keySerializer);
		JdkSerializationRedisSerializer jdkSerializationRedisSerializer=new JdkSerializationRedisSerializer();
		redisTemplate.setValueSerializer(jdkSerializationRedisSerializer);
		return redisTemplate;
	}

	// cache manager
	@Bean()
	public RedisCacheManager cacheManager(@Value("#{redisTemplate}") RedisTemplate redisTemplate) {
		RedisCacheManager redisCacheManager = new RedisCacheManager(redisTemplate);
		return redisCacheManager;
	}
	//以下是activemq设置 http://elim.iteye.com/blog/1893038
	//配置ConnectionFactory,公共部分
	@Bean()
	public ActiveMQConnectionFactory targetConnectionFactory(@Value("${mq.url}") String url) {
		ActiveMQConnectionFactory targetConnectionFactory = new ActiveMQConnectionFactory();
		targetConnectionFactory.setBrokerURL(url);
		return targetConnectionFactory;
	}
	@Bean()
	public SingleConnectionFactory jmsConnectionFactory(@Value("#{targetConnectionFactory}") ActiveMQConnectionFactory targetConnectionFactory) {
		SingleConnectionFactory connectionFactory = new SingleConnectionFactory();
		connectionFactory.setTargetConnectionFactory(targetConnectionFactory);
		return connectionFactory;
	}
	
	   /**
	    *以下是点对点模式的配置
	    *1、利用JmsTemplate进行消息发送的时候，我们需要知道消息发送的目的地，即destination
		*以下是点对点模式的配置
		*这个是队列目的地，点对点的*/
		@Bean()
		public ActiveMQQueue queueDestination(@Value("${mq.queue}") String queueName) {
			ActiveMQQueue queueDestination = new ActiveMQQueue(queueName);
			return queueDestination;
		}
		
		 //2、 配置点对点模式发送生产者，配置JMS连接工厂 Spring提供的JMS工具类，它可以进行消息发送、接收等
	@Bean()
	public JmsTemplate jmsTemplate(@Value("#{jmsConnectionFactory}") SingleConnectionFactory jmsConnectionFactory,@Value("#{queueDestination}") ActiveMQQueue queueDestination) {
		JmsTemplate jmsTemplate = new JmsTemplate();
		jmsTemplate.setConnectionFactory(jmsConnectionFactory);
		jmsTemplate.setDefaultDestination(queueDestination);
		jmsTemplate.setReceiveTimeout(10000);
		return jmsTemplate;
	}
	
	 //3、配置消费者,配置接收消息	
	 //配置一个消息监听容器
	 //消息监听器
	@Bean()
	public ConsumerMessageListener consumerMessageListener() {
		ConsumerMessageListener consumerMessageListener = new ConsumerMessageListener();
		return consumerMessageListener;
	}	
	//消息监听器容器     
	@Bean()
	public DefaultMessageListenerContainer jmsContainer(@Value("#{jmsConnectionFactory}") SingleConnectionFactory jmsConnectionFactory,@Value("#{queueDestination}") ActiveMQQueue queueDestination,@Value("#{consumerMessageListener}") ConsumerMessageListener messageListener) {
		DefaultMessageListenerContainer jmsContainer = new DefaultMessageListenerContainer();
		jmsContainer.setConnectionFactory(jmsConnectionFactory);
		jmsContainer.setDestination(queueDestination);
		jmsContainer.setMessageListener(messageListener);
		return jmsContainer;
	}
	/**
	 * 以下是主题模式配置即主题消息收发
	 * 这个是主题目的地，一对多的，定义消息主题topic
	 */
	@Bean()
	public ActiveMQTopic topicDestination(@Value("${mq.topic}") String topicName) {
		ActiveMQTopic topicDestination = new ActiveMQTopic(topicName);
		return topicDestination;
	}	
	// 配置JMS模板（Topic），pubSubDomain="true"
	@Bean()
	public JmsTemplate topicJmsTemplate(@Value("#{jmsConnectionFactory}") SingleConnectionFactory jmsConnectionFactory,@Value("#{topicDestination}") ActiveMQTopic topicDestination) {
		JmsTemplate jmsTemplate = new JmsTemplate();
		jmsTemplate.setConnectionFactory(jmsConnectionFactory);
		//主题（Topic）和队列消息的主要差异体现在JmsTemplate中"pubSubDomain"是否设置为True。如果为True，则是Topic
		jmsTemplate.setPubSubDomain(true);
		jmsTemplate.setDefaultDestination(topicDestination);
		jmsTemplate.setReceiveTimeout(10000);
		return jmsTemplate;
	}
	// 消息主题监听者 和 主题监听容器 可以配置多个，即多个订阅者  
	//消息主题监听者(Topic) -->  
	//3、配置消费者,配置接收消息	
	//配置一个消息监听容器
	//消息监听器
	@Bean()
	public TopicMessageListener topicMessageListener() {
		TopicMessageListener topicMessageListener = new TopicMessageListener();
		return topicMessageListener;
	}	
	//消息监听器容器     
	@Bean()
	public DefaultMessageListenerContainer topicJmsContainer(@Value("#{jmsConnectionFactory}") SingleConnectionFactory jmsConnectionFactory,@Value("#{topicDestination}") ActiveMQTopic topicDestination,@Value("#{topicMessageListener}") TopicMessageListener topicMessageListener) {
		DefaultMessageListenerContainer jmsContainer = new DefaultMessageListenerContainer();
		jmsContainer.setConnectionFactory(jmsConnectionFactory);
		jmsContainer.setDestination(topicDestination);
		jmsContainer.setMessageListener(topicMessageListener);
		return jmsContainer;
	}

}
