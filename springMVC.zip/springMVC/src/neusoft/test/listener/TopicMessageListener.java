package neusoft.test.listener;

import javax.jms.BytesMessage;
import javax.jms.JMSException;
import javax.jms.Message;
import javax.jms.MessageListener;
import javax.jms.TextMessage;

public class TopicMessageListener implements MessageListener {

	@Override
	public void onMessage(Message message) {
		if (message instanceof TextMessage){
			TextMessage tm = (TextMessage) message;  
			System.out.println("接收到一个topic消息。");  
	        try {  
	            System.out.println("TopicMessageListener \t" + tm.getText());  
	        } catch (JMSException e) {  
	            e.printStackTrace();  
	        }  
		}
		if (message instanceof BytesMessage){
			BytesMessage m=(BytesMessage)message;
			System.out.println(m); 
		}
	}

}
