package neusoft.test.controller;

import java.util.List;

import org.springframework.beans.factory.annotation.Value;
import org.springframework.beans.factory.config.BeanDefinition;
import org.springframework.context.annotation.Scope;
import org.springframework.stereotype.Controller;
import org.springframework.web.bind.annotation.PathVariable;
import org.springframework.web.bind.annotation.RequestMapping;
import org.springframework.web.bind.annotation.RequestMethod;
import org.springframework.web.bind.annotation.RequestParam;
import org.springframework.web.multipart.MultipartFile;
import org.springframework.web.servlet.ModelAndView;

import neusoft.test.module.domain.User;
import neusoft.test.module.service.IQueueManager;
import neusoft.test.module.service.IUserManager;

@Controller
@Scope(BeanDefinition.SCOPE_SINGLETON)
@RequestMapping(value = "/user")
public class UserController {
	@Value("#{userManager}")
	private IUserManager userManager;
	@Value("#{queueManager}")
	private IQueueManager queueManager;
	@RequestMapping(value = "/userLogin", method = { RequestMethod.GET,RequestMethod.POST })
	public ModelAndView userLogin(
			@RequestParam(required=true,value="userName") String userName,
			@RequestParam(required=true,value="userPwd") String userPwd,
			@RequestParam(required=true,value="pageNum",defaultValue="1") int pageNum,
			@RequestParam(required=true,value="pageSize",defaultValue="10") int pageSize,
			@RequestParam("userPhoto") MultipartFile file) {
		 
		
		this.userManager.userLogin(userName,userPwd);
		this.queueManager.sendMessage(userName+"login");
		this.queueManager.publish(userName+"topic msg");
		List<User> userList=this.userManager.getAll(pageNum,pageSize);
		ModelAndView mv=new ModelAndView("list");
		mv.addObject("userList", userList);
		mv.addObject("currentUserName", userName);
		return mv;
	}
	@RequestMapping(path = "/getUser/{userName}", method = RequestMethod.GET)
	public ModelAndView getUser(@PathVariable("userName") String userName) {
		ModelAndView mv=new ModelAndView("userInfo");
		mv.addObject("userName", userName);
		return mv;
	}
	@RequestMapping(value = "/ajax", method = { RequestMethod.GET,RequestMethod.POST })
	public ModelAndView ajax(
			@RequestParam(required=true,value="userName") String userName,
			@RequestParam(required=true,value="userPwd") String userPwd) {
		ModelAndView mv=new ModelAndView("userInfo");
		mv.addObject("userName", userName);
		return mv;
	}
	@RequestMapping(value = "/add", method = { RequestMethod.GET,RequestMethod.POST })
	public ModelAndView add() {
		ModelAndView mv=new ModelAndView("adduser");
		return mv;
	}
	@RequestMapping(value = "/main", method = { RequestMethod.GET,RequestMethod.POST })
	public ModelAndView gomain() {
		ModelAndView mv=new ModelAndView("main");
		return mv;
	}
}
